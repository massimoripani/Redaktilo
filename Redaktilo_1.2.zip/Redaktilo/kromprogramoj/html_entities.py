
# -*- coding: utf-8 -*-
"""Konvertas HTML-entojn al UTF-8-signoj per ekstera vortaro."""

import os
import re

CATEGORY = "Teksto"
NAME = "Konverti HTML-entojn al signoj"

VORTARO_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "vortaroj",
    "html_entoj.txt"
)

PROTEKTITAJ = {"&amp;", "&lt;", "&gt;"}


def legi_vortaron():
    vortaro = {}

    with open(VORTARO_PATH, encoding="utf-8") as f:
        for linio in f:
            linio = linio.strip()

            if not linio or linio.startswith("#"):
                continue

            if "=" not in linio:
                continue

            ento, signo = linio.split("=", 1)
            ento = ento.strip()

            if ento and ento not in PROTEKTITAJ:
                vortaro[ento] = signo

    return vortaro


def konverti_entojn(teksto):
    vortaro = legi_vortaron()

    if not vortaro:
        return teksto

    # Unue la plej longaj entoj
    entoj = sorted(vortaro, key=len, reverse=True)

    pattern = re.compile(
        "|".join(re.escape(ento) for ento in entoj)
        + r"|&#(?:[0-9]+|[xX][0-9a-fA-F]+);"
    )

    def anstataŭigi(match):
        ento = match.group(0)

        if ento in PROTEKTITAJ:
            return ento

        if ento in vortaro:
            return vortaro[ento]

        # Numeraj entoj: dekumaj kaj deksesumaj
        if ento.startswith("&#"):
            valoro = ento[2:-1]

            try:
                if valoro.startswith(("x", "X")):
                    kodo = int(valoro[1:], 16)
                else:
                    kodo = int(valoro, 10)

                if (
                    0 <= kodo <= 0x10FFFF
                    and not 0xD800 <= kodo <= 0xDFFF
                ):
                    return chr(kodo)

            except ValueError:
                pass

        return ento

    return pattern.sub(anstataŭigi, teksto)


def run(ctx):
    try:
        ctx.apply(konverti_entojn)
    except FileNotFoundError:
        ctx.error("La vortaro html_entoj.txt ne estis trovita.")
    except Exception as e:
        ctx.error(f"Eraro dum konvertado: {e}")
